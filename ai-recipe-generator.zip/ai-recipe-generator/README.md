# AI Recipe Generator — Kamryn Jones

A mobile-friendly React + TypeScript / Vite recipe suggestion website.

## Run locally

```bash
npm install
npm run dev
```

## Deploy on AWS Amplify

Push these files to the root of a GitHub repository, then connect that repository in AWS Amplify Hosting. Set the build command to `npm run build` and the output directory to `dist` (Amplify often detects Vite automatically).

## Important

This is a functional **local recipe suggestion demo**, not a generative AI integration. It matches ingredients against a small built-in recipe list. A real AI service would require a backend/API integration and credentials stored securely on the server, never in frontend source code.
